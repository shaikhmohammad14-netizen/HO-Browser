package com.hobrowser

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.animation.OvershootInterpolator
import android.widget.*
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import java.net.URLEncoder

class MainActivity : Activity() {
    private lateinit var runtime: GeckoRuntime
    private lateinit var session: GeckoSession
    private lateinit var browser: GeckoView
    private lateinit var root: LinearLayout
    private lateinit var address: EditText
    private var currentPage = "home"
    private var glassOpacity = 58
    private var accent = Color.rgb(65, 105, 255)
    private var preferredHz = 120f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 14, 25)
        window.navigationBarColor = Color.rgb(12, 14, 25)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        requestRefreshRate(preferredHz)
        runtime = GeckoRuntime.create(this)
        session = GeckoSession()
        session.setContentDelegate(object : GeckoSession.ContentDelegate {
            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                if (fullScreen) window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            }
        })
        session.open(runtime)
        browser = GeckoView(this).apply { setSession(this@MainActivity.session) }
        showHome()
    }

    private fun baseLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(10))
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(12, 16, 37), Color.rgb(32, 35, 78), Color.rgb(13, 18, 42)))
    }

    private fun showHome() {
        currentPage = "home"
        root = baseLayout()
        val header = row()
        header.addView(label("HO  BROWSER", 17f, Color.WHITE, true), LinearLayout.LayoutParams(0, dp(42), 1f))
        header.addView(textButton("Tabs 1") { showTabs() })
        header.addView(textButton("⋮") { showSettings() })
        root.addView(header)

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, dp(18), 0, 0) }
        val logo = TextView(this).apply {
            text = "HO"; textSize = 31f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            background = glass(110); setPadding(dp(24), dp(15), dp(24), dp(15))
        }
        content.addView(logo)
        content.addView(label("HO Browser", 25f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) })
        content.addView(label("Fast  ·  Smart  ·  Secure", 12f, Color.LTGRAY, false).apply { gravity = Gravity.CENTER })
        val search = EditText(this).apply {
            hint = "Search or enter address"; setSingleLine(true); textSize = 15f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setPadding(dp(18), 0, dp(18), 0)
            background = glass(100); imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, _ -> if (action == EditorInfo.IME_ACTION_GO) { navigate(text.toString()); true } else false }
        }
        address = search
        val searchLp = LinearLayout.LayoutParams(-1, dp(54)); searchLp.topMargin = dp(38)
        content.addView(search, searchLp)
        val shortcuts = listOf(
            Triple("G", "Google", "https://www.google.com"), Triple("▶", "YouTube", "https://m.youtube.com"),
            Triple("f", "Facebook", "https://m.facebook.com"), Triple("◎", "Instagram", "https://www.instagram.com"),
            Triple("𝕏", "X", "https://x.com"), Triple("W", "Wikipedia", "https://www.wikipedia.org"),
            Triple("a", "Amazon", "https://www.amazon.in"), Triple("+", "Add", "")
        )
        for (start in shortcuts.indices step 4) {
            val line = row().apply { gravity = Gravity.CENTER; setPadding(0, dp(18), 0, 0) }
            shortcuts.drop(start).take(4).forEach { item ->
                val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isClickable = true; setOnClickListener { if (item.third.isNotEmpty()) openUrl(item.third) else Toast.makeText(this@MainActivity, "Shortcut editing is coming next", Toast.LENGTH_SHORT).show() } }
                val glyph = TextView(this).apply { text = item.first; textSize = 25f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = glass(25); setPadding(dp(16), dp(12), dp(16), dp(12)) }
                cell.addView(glyph)
                cell.addView(label(item.second, 11f, Color.WHITE, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) })
                line.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
            }
            content.addView(line)
        }
        val discover = TextView(this).apply {
            text = "◉  Discover                                      ›\n\nThe growth story continues in 2026"
            textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(18), dp(18), dp(18), dp(22)); background = glass(24)
            setOnClickListener { openUrl("https://news.google.com") }
        }
        val discoverLp = LinearLayout.LayoutParams(-1, dp(118)); discoverLp.topMargin = dp(22)
        content.addView(discover, discoverLp)
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomBar("home"))
        setContentView(root)
    }

    private fun showBrowser(url: String? = null) {
        currentPage = "browser"
        root = baseLayout()
        val bar = row()
        bar.addView(textButton("‹") { showHome() })
        address = EditText(this).apply { hint = "Search or enter address"; setSingleLine(true); textSize = 14f; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setPadding(dp(14), 0, dp(14), 0); background = glass(100); imeOptions = EditorInfo.IME_ACTION_GO; setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_GO) { navigate(text.toString()); true } else false } }
        bar.addView(address, LinearLayout.LayoutParams(0, dp(48), 1f))
        bar.addView(textButton("↻") { session.reload() })
        root.addView(bar)
        root.addView(browser, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomBar("browser"))
        setContentView(root)
        if (url != null) { address.setText(url); session.loadUri(url) }
    }

    private fun showSettings() {
        currentPage = "settings"
        root = baseLayout()
        val header = row(); header.addView(textButton("‹") { showHome() }); header.addView(label("Settings", 22f, Color.WHITE, true).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), 0, 0, 0) })
        root.addView(header)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(18), 0, 0) }
        list.addView(settingRow("HO account", "Your browser profile") { Toast.makeText(this, "Account setup is not connected yet", Toast.LENGTH_SHORT).show() })
        list.addView(settingRow("Liquid glass and layout", "Blur, transparency and shape") { showCustomize() })
        list.addView(settingRow("Appearance", "Dark glass · Blue accent") { showCustomize() })
        list.addView(settingRow("Refresh rate", "Preferred ${preferredHz.toInt()} Hz") { chooseRefreshRate() })
        list.addView(settingRow("Ad block", "Not enabled in this starter build") { Toast.makeText(this, "Content blocking will be added in a later build", Toast.LENGTH_LONG).show() })
        list.addView(settingRow("Privacy and security", "Site permissions and browsing data") { privacyDialog() })
        list.addView(settingRow("Extensions", "GeckoView extension support planned") { Toast.makeText(this, "Extensions are not configured yet", Toast.LENGTH_SHORT).show() })
        list.addView(settingRow("Downloads", "Download manager") { showDownloads() })
        val scroll = ScrollView(this); scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); root.addView(bottomBar("settings")); setContentView(root)
    }

    private fun showCustomize() {
        currentPage = "customize"; root = baseLayout()
        val header = row(); header.addView(textButton("‹") { showSettings() }); header.addView(label("Customize", 22f, Color.WHITE, true)); root.addView(header)
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = glass(26); setPadding(dp(18), dp(18), dp(18), dp(18)) }
        panel.addView(label("Glass opacity", 16f, Color.WHITE, true))
        val opacity = SeekBar(this).apply { max = 100; progress = glassOpacity; setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { glassOpacity = p }; override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) { showCustomize() } }) }
        panel.addView(opacity)
        panel.addView(label("Accent color", 16f, Color.WHITE, true).apply { setPadding(0, dp(18), 0, dp(8)) })
        val colors = row(); listOf(Color.rgb(65,105,255), Color.rgb(0,190,150), Color.rgb(180,90,255), Color.rgb(255,130,55), Color.rgb(235,80,125), Color.WHITE).forEach { c -> val b = View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }; setOnClickListener { accent = c; showCustomize() } }; colors.addView(b, LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) }) }
        panel.addView(colors); panel.addView(label("Touch animation", 16f, Color.WHITE, true).apply { setPadding(0, dp(18), 0, dp(8)) })
        panel.addView(label("Buttons use a spring-like press animation.", 13f, Color.LTGRAY, false))
        root.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f)); root.addView(bottomBar("customize")); setContentView(root)
    }

    private fun showTabs() { currentPage = "tabs"; root = baseLayout(); root.addView(label("‹     Tabs", 22f, Color.WHITE, true).apply { setOnClickListener { showHome() } }); root.addView(settingRow("Tab 1", "Current browsing session") { showBrowser() }); root.addView(label("This starter currently supports one active tab. Multi-tab management is planned.", 13f, Color.LTGRAY, false)); root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f)); root.addView(bottomBar("tabs")); setContentView(root) }
    private fun showDownloads() { currentPage = "downloads"; root = baseLayout(); root.addView(label("‹     Downloads", 22f, Color.WHITE, true).apply { setOnClickListener { showSettings() } }); root.addView(label("No downloads are recorded yet. Download interception and a full download manager are planned for a later build.", 14f, Color.LTGRAY, false).apply { setPadding(0, dp(24), 0, 0) }); root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f)); root.addView(bottomBar("downloads")); setContentView(root) }

    private fun privacyDialog() { val items = arrayOf("Clear browsing history", "Clear cookies and site data", "Clear cache"); android.app.AlertDialog.Builder(this).setTitle("Privacy and security").setItems(items) { _, which -> Toast.makeText(this, "Use Android app storage to clear all GeckoView data in this starter build.", Toast.LENGTH_LONG).show() }.setNegativeButton("Close", null).show() }
    private fun chooseRefreshRate() { val opts = arrayOf("60 Hz", "90 Hz", "120 Hz"); android.app.AlertDialog.Builder(this).setTitle("Preferred refresh rate").setItems(opts) { _, i -> preferredHz = listOf(60f,90f,120f)[i]; requestRefreshRate(preferredHz); showSettings() }.show() }
    private fun requestRefreshRate(hz: Float) { val modes = if (android.os.Build.VERSION.SDK_INT >= 23) display?.supportedModes?.map { it.refreshRate }?.distinct().orEmpty() else emptyList(); val chosen = modes.minByOrNull { kotlin.math.abs(it-hz) } ?: hz; window.attributes = window.attributes.apply { preferredRefreshRate = chosen } }
    private fun navigate(raw: String) { val input = raw.trim(); if (input.isEmpty()) return; val url = when { input.startsWith("https://") || input.startsWith("http://") -> input; input.contains(".") && !input.contains(" ") -> "https://$input"; else -> "https://www.google.com/search?q=" + URLEncoder.encode(input, "UTF-8") }; if (currentPage != "browser") showBrowser(url) else { address.setText(url); session.loadUri(url) } }
    private fun openUrl(url: String) { showBrowser(url) }
    private fun bottomBar(active: String): LinearLayout { val bar = row().apply { background = glass(100); gravity = Gravity.CENTER; setPadding(dp(4), dp(5), dp(4), dp(5)) }; listOf("‹" to "back", "›" to "forward", "⌂" to "home", "▢" to "tabs", "☰" to "settings").forEach { (symbol, key) -> val b = TextView(this).apply { text = symbol; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = if (active == key) solid(accent, 100) else null; setOnClickListener { when(key) { "back" -> if (::session.isInitialized) session.goBack(); "forward" -> if (::session.isInitialized) session.goForward(); "home" -> showHome(); "tabs" -> showTabs(); "settings" -> showSettings() } } }; bar.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f)) }; return bar }
    private fun settingRow(title: String, subtitle: String, action: () -> Unit): View { val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = glass(20); setPadding(dp(16), dp(14), dp(16), dp(14)); isClickable = true; setOnClickListener { action() } }; box.addView(label(title, 15f, Color.WHITE, true)); box.addView(label(subtitle, 12f, Color.LTGRAY, false)); val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); box.layoutParams = lp; return box }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun textButton(text: String, action: () -> Unit): TextView = TextView(this).apply { this.text = text; textSize = 17f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(dp(10), dp(8), dp(10), dp(8)); setOnClickListener { spring(this); action() } }
    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply { this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD) }
    private fun glass(radius: Int): GradientDrawable = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = dp(radius).toFloat(); setColor(Color.argb(glassOpacity.coerceIn(10,90), 220,230,255)); setStroke(dp(1), Color.argb(115,255,255,255)) }
    private fun solid(color: Int, radius: Int) = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; cornerRadius = dp(radius).toFloat(); setColor(color) }
    private fun spring(v: View) { v.animate().scaleX(.9f).scaleY(.9f).setDuration(80).withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(230).setInterpolator(OvershootInterpolator(2f)).start() }.start() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onBackPressed() { when(currentPage) { "browser" -> showHome(); "customize", "downloads" -> showSettings(); "settings", "tabs" -> showHome(); else -> super.onBackPressed() } }
    override fun onDestroy() { if (::session.isInitialized) session.close(); super.onDestroy() }
}
