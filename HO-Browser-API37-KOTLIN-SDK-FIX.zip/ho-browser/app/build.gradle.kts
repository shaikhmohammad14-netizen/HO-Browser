plugins {
    id("com.android.application")
}
android {
    namespace = "com.hobrowser"
    compileSdk = 37
    compileSdkExtension = 2
    defaultConfig {
        applicationId = "com.hobrowser"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
configurations.configureEach {
    resolutionStrategy.force("org.jetbrains.kotlin:kotlin-stdlib:2.3.0")
    resolutionStrategy.force("org.jetbrains.kotlin:kotlin-stdlib-jdk7:2.3.0")
    resolutionStrategy.force("org.jetbrains.kotlin:kotlin-stdlib-jdk8:2.3.0")
}

dependencies {
    implementation("org.mozilla.geckoview:geckoview:160.0.20261116130455")
}
