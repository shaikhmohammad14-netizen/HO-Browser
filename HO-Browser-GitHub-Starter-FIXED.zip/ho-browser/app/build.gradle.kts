plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.hobrowser"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.hobrowser"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
dependencies {
    implementation("org.mozilla.geckoview:geckoview:160.0.20261116130455")
}
